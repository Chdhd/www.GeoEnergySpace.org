/* ============================================================
   GESNRI — Roadmap (2026–2030) & Dynamic Access Point
   Renders the institute's multi-year roadmap and a role-based
   access panel (Researchers / Clients / Investors) into the
   home page. Pure client-side — no build step required.
   ============================================================ */

(function () {
  "use strict";

  /* ---------- Roadmap data, 2026–2030 ---------- */
  var ROADMAP = [
    {
      year: "2026",
      status: "current",
      title: "Institutional Scale-Up",
      pillar: "All Pillars",
      copy: "Formalize partnership agreements with universities, NGOs, and government agencies; take the Sustainable Energy Development and Smart-Climate Integration projects into their first regional pilots."
    },
    {
      year: "2027",
      status: "upcoming",
      title: "Regional Data Network",
      pillar: "Pillar I",
      copy: "Establish multi-country geospatial data-sharing agreements and launch a second-generation open data portal with expanded access for researchers, clients, and investors."
    },
    {
      year: "2028",
      status: "upcoming",
      title: "Applied Deployment at Scale",
      pillar: "Pillar II",
      copy: "Move climate-risk and energy-siting tools from pilot to field deployment with government and humanitarian partners; place the first cohort of GESNRI-trained researchers with partner institutions."
    },
    {
      year: "2029",
      status: "upcoming",
      title: "Small-Satellite Feasibility Milestone",
      pillar: "Pillar III",
      copy: "Complete feasibility research and partnership groundwork for a regional small-satellite Earth-observation concept, building on the Space Exploration project's research track."
    },
    {
      year: "2030",
      status: "upcoming",
      title: "Nexus Consolidation",
      pillar: "All Pillars",
      copy: "Operate as the region's reference open-data nexus for space, climate, and energy research, sustained by a diversified mix of grants, service contracts, and long-term partnerships."
    }
  ];

  /* ---------- Dynamic access point data ---------- */
  var ACCESS_POINTS = {
    researchers: {
      label: "Researchers",
      heading: "Open data, collaboration, and fellowships.",
      copy: "Query and download GESNRI's open datasets, propose joint research under any of the three pillars, or apply for a research fellowship. We actively co-author with partner institutions rather than publishing in isolation.",
      actions: ["Access open datasets", "Propose a joint study", "Apply for a fellowship"],
      mailSubject: "Researcher Access Request"
    },
    clients: {
      label: "Clients",
      heading: "Commissioned analysis and data products.",
      copy: "Organizations needing geospatial analysis, energy-siting studies, or climate-risk briefings can commission work directly from GESNRI's research teams, scoped to your operational timeline.",
      actions: ["Request a scoped study", "License a data product", "Discuss a service agreement"],
      mailSubject: "Client Inquiry"
    },
    investors: {
      label: "Investors",
      heading: "Fund the roadmap, not just a project.",
      copy: "GESNRI works with funding partners who want measurable regional impact — from sponsoring a single pillar's work to backing the 2026–2030 roadmap as a whole.",
      actions: ["Review funding priorities", "Sponsor a pillar", "Discuss multi-year support"],
      mailSubject: "Investor Inquiry"
    }
  };

  var CONTACT_EMAIL = "charlesdlual@gmail.com";

  /* ---------- Roadmap rendering ---------- */
  function renderRoadmap() {
    var track = document.getElementById("roadmap-track");
    if (!track) return;

    var html = ROADMAP.map(function (stop, i) {
      return (
        '<div class="road-stop ' + (stop.status === "current" ? "is-current" : "") + '">' +
          '<div class="road-year">' + stop.year + (stop.status === "current" ? '<span class="road-badge">IN PROGRESS</span>' : "") + "</div>" +
          '<div class="road-pillar">' + stop.pillar + "</div>" +
          '<h3>' + stop.title + "</h3>" +
          "<p>" + stop.copy + "</p>" +
        "</div>"
      );
    }).join("");

    track.innerHTML = html;
  }

  /* ---------- Dynamic access point rendering ---------- */
  function renderAccessPanel(key) {
    var panel = document.getElementById("access-panel");
    if (!panel) return;
    var data = ACCESS_POINTS[key];
    if (!data) return;

    var actionsHtml = data.actions.map(function (a) {
      return "<li>" + a + "</li>";
    }).join("");

    panel.innerHTML =
      '<h3>' + data.heading + "</h3>" +
      "<p>" + data.copy + "</p>" +
      '<ul class="access-actions">' + actionsHtml + "</ul>" +
      '<a class="btn btn-primary" href="mailto:' + CONTACT_EMAIL + "?subject=" + encodeURIComponent(data.mailSubject) + '">Reach out as a ' + data.label.slice(0, -1) + "</a>";
  }

  function initAccessTabs() {
    var tabs = document.getElementById("access-tabs");
    if (!tabs) return;

    tabs.addEventListener("click", function (evt) {
      var btn = evt.target.closest("[data-access]");
      if (!btn) return;

      var current = tabs.querySelector(".is-active");
      if (current) current.classList.remove("is-active");
      btn.classList.add("is-active");

      renderAccessPanel(btn.getAttribute("data-access"));
    });

    // default view
    var first = tabs.querySelector("[data-access]");
    if (first) {
      first.classList.add("is-active");
      renderAccessPanel(first.getAttribute("data-access"));
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    renderRoadmap();
    initAccessTabs();
  });
})();
